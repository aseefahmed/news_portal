Dear User, <br>
{{ $info['details'] }}